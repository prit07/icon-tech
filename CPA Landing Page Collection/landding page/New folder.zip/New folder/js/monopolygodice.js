$( document ).ready(function() {
  

  //  Stap one Js
    
    
    $('.input-1').keyup(function(){
      let len = this.value.length;
  
      if (len === 0) {
        $('.form-1 .progress-bar_item').each(function() {
          $(this).removeClass('active')
        });
        $('.form-1 .active').css('background-color', 'transparent');
      } else if (len > 0 == len <= 1) {
        $('.form-1 .progress-bar_item-1').addClass('active');
        $('.form-1 .progress-bar_item-2').removeClass('active');
        $('.form-1 .progress-bar_item-3').removeClass('active');
        $('.form-1 .active').css('background-color', '#ff0000');

      } else if (len > 1== len <= 2) {
        $('.form-1 .progress-bar_item-1').addClass('active');
        $('.form-1 .progress-bar_item-2').addClass('active');
        $('.form-1 .progress-bar_item-3').removeClass('active');
        $('.form-1 .active').css('background-color', '#ffa500');
    
      } else {
        $('.form-1 .progress-bar_item').each(function() {
          $(this).addClass('active');
        });
        $('.form-1 .active').css('background-color', '#008000');
  ;
      } 
    });
    
  });
    
  
  
  