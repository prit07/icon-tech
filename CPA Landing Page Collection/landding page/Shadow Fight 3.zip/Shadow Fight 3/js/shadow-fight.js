$(document).ready(function() {
    $('.owl-shadow-fight').owlCarousel({
        loop:true,
        margin:10,
        nav:true,
        items:1,
        navText: [
			'<span><img src="img/left.png"</span>',
			'<span><img src="img/right.png"</span>'
		],
    })
})
  