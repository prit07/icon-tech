$(document).ready(function(){
    $('.descripcion-tabs li').click(function(){
     $('.descripcion-tabs li').removeClass('active');
     $('.content').removeClass('active');
     var tid=$(this).attr('tab');
     $(this).addClass('active');
     $('#' +tid).addClass('active');
    });

    var inner_height = $('.detail-tab-text').height();
	console.log(inner_height);

	$(".show-more").click(function () {
		if($(".detail-tab-text").hasClass("show-more-height")) {
			$(this).text("VER MENOS");
		} else {
			$(this).text("VER MÁS");
		}

		$(".detail-tab-text").toggleClass("show-more-height");
	});
 });